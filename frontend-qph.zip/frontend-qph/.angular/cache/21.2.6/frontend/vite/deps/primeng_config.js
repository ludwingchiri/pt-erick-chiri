import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-3NTZEPTM.js";
import "./chunk-T6CLMSOF.js";
import "./chunk-6VT5MDB4.js";
import "./chunk-2327E2AU.js";
import "./chunk-UIJR6EBG.js";
import "./chunk-DR5S4X4P.js";
import "./chunk-RSS3ODKE.js";
import "./chunk-3OV72XIM.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};

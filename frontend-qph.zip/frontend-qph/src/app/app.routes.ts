import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth-guard';

export const routes: Routes = [
  { path: '', redirectTo: 'products', pathMatch: 'full' },
  {
    path: 'login',
    loadComponent: () =>
      import('./features/auth/login/login').then(m => m.LoginComponent)
  },
  {
    path: 'products',
    canActivate: [authGuard],
    loadChildren: () =>
      import('./features/products/products.routes').then(m => m.PRODUCT_ROUTES)
  },
  {
    path: 'usuarios',
    canActivate: [authGuard],
    loadChildren: () =>
      import('./features/usuarios/usuarios.routes').then(m => m.USUARIO_ROUTES)
  },
  {
    path: 'ventas',
    canActivate: [authGuard],
    loadChildren: () =>
      import('./features/ventas/ventas.routes').then(m => m.VENTA_ROUTES)
  },
  { path: '**', redirectTo: 'products' }
];

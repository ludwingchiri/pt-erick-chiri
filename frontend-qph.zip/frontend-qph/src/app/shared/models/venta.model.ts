export type EstadoVenta = 'REGISTRADA' | 'ANULADA';

export interface VentaDetalle {
  id?: number;
  venta_id?: number;
  product_id: number;
  cantidad: number;
  precio_unitario: number;
  subtotal: number;
  product?: {
    id: number;
    nombre: string;
  };
}

export interface Venta {
  id?: number;
  usuario_id: number;
  fecha: string;
  total: number;
  estado: EstadoVenta;
  detalles: VentaDetalle[];
  usuario?: {
    id: number;
    usuario: string;
    nombre: string;
    apellido: string;
  };
}

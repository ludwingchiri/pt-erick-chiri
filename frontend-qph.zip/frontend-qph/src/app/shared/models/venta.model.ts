export type EstadoVenta = 'REGISTRADA' | 'ANULADA';

export interface VentaDetalle {
  id: number;
  productId: number;
  productNombre: string;
  cantidad: number;
  precioUnitario: number;
  subtotal: number;
}

export interface Venta {
  id: number;
  usuarioId: number;
  usuario: string | UsuarioVenta;
  fecha: string;
  total: number;
  estado: EstadoVenta;
  detalles: VentaDetalle[];
}

export interface UsuarioVenta {
  usuario?: string;
  nombre?: string;
  apellido?: string;
}

export interface VentaRequest {
  detalles: VentaDetalleRequest[];
}

export interface VentaDetalleRequest {
  productId: number;
  cantidad: number;
}

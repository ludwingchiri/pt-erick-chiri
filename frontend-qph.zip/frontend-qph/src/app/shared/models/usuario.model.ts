export interface Usuario {
  id: number;
  usuario: string;
  nombre: string;
  apellido: string;
  estado: boolean;
}

export interface UsuarioCreateRequest {
  usuario: string;
  nombre: string;
  apellido: string;
  contrasena: string;
  estado: boolean;
}

export interface UsuarioUpdateRequest {
  usuario: string;
  nombre: string;
  apellido: string;
  estado: boolean;
}

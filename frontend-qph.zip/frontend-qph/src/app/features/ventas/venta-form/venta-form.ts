import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormArray, FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../../../core/services/product';
import { UsuarioService } from '../../../core/services/usuario';
import { VentaService } from '../../../core/services/venta';
import { Product } from '../../../shared/models/product.model';
import { Usuario } from '../../../shared/models/usuario.model';
import { EstadoVenta, Venta, VentaDetalle } from '../../../shared/models/venta.model';
import { ButtonModule } from 'primeng/button';
import { InputNumberModule } from 'primeng/inputnumber';
import { InputTextModule } from 'primeng/inputtext';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-venta-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, ButtonModule, InputNumberModule, InputTextModule, ToastModule],
  providers: [MessageService],
  templateUrl: './venta-form.html',
  styleUrls: ['./venta-form.scss']
})
export class VentaFormComponent implements OnInit {
  private fb = inject(FormBuilder);
  private ventaService = inject(VentaService);
  private productService = inject(ProductService);
  private usuarioService = inject(UsuarioService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private messageService = inject(MessageService);

  form = this.fb.nonNullable.group({
    usuario_id: this.fb.control<number | null>(null, Validators.required),
    fecha: [this.getCurrentDateTime(), Validators.required],
    estado: ['REGISTRADA' as EstadoVenta, Validators.required],
    detalles: this.fb.array([])
  });
  usuarios: Usuario[] = [];
  products: Product[] = [];
  isEdit = false;
  ventaId?: number;
  loading = false;
  submitting = false;

  get detalles(): FormArray {
    return this.form.controls.detalles;
  }

  get total(): number {
    return this.detalles.controls.reduce((total, control) => total + Number(control.get('subtotal')?.value ?? 0), 0);
  }

  ngOnInit(): void {
    this.loadCatalogs();
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEdit = true;
      this.ventaId = Number(id);
      this.loadVenta(this.ventaId);
    } else {
      this.addDetalle();
    }
  }

  private loadCatalogs(): void {
    this.usuarioService.getAll().subscribe({
      next: usuarios => this.usuarios = usuarios.filter(usuario => usuario.estado),
      error: () => this.showCatalogError('usuarios')
    });
    this.productService.getAll().subscribe({
      next: products => this.products = products,
      error: () => this.showCatalogError('productos')
    });
  }

  private loadVenta(id: number): void {
    this.loading = true;
    this.ventaService.getById(id).subscribe({
      next: venta => {
        this.form.patchValue({
          usuario_id: venta.usuario_id,
          fecha: this.toDateTimeLocal(venta.fecha),
          estado: venta.estado
        });
        (venta.detalles ?? []).forEach(detalle => this.addDetalle(detalle));
        this.loading = false;
      },
      error: () => {
        this.messageService.add({ severity: 'error', summary: 'Error', detail: 'No se pudo cargar la venta' });
        this.loading = false;
      }
    });
  }

  addDetalle(detalle?: VentaDetalle): void {
    this.detalles.push(this.fb.group({
      product_id: this.fb.control<number | null>(detalle?.product_id ?? null, Validators.required),
      cantidad: this.fb.control(detalle?.cantidad ?? 1, [Validators.required, Validators.min(1)]),
      precio_unitario: this.fb.control(detalle?.precio_unitario ?? 0, [Validators.required, Validators.min(0)]),
      subtotal: this.fb.control(detalle?.subtotal ?? 0)
    }));
  }

  removeDetalle(index: number): void {
    this.detalles.removeAt(index);
  }

  onProductChange(index: number): void {
    const detalle = this.detalles.at(index);
    const productId = Number(detalle.get('product_id')?.value);
    const product = this.products.find(item => item.id === productId);
    if (!product) return;
    detalle.patchValue({ precio_unitario: product.precio });
    this.calculateSubtotal(index);
  }

  calculateSubtotal(index: number): void {
    const detalle = this.detalles.at(index);
    const cantidad = Number(detalle.get('cantidad')?.value ?? 0);
    const precio = Number(detalle.get('precio_unitario')?.value ?? 0);
    detalle.get('subtotal')?.setValue(Number((cantidad * precio).toFixed(2)));
  }

  onSubmit(): void {
    if (this.form.invalid || this.detalles.length === 0) {
      this.form.markAllAsTouched();
      if (this.detalles.length === 0) {
        this.messageService.add({ severity: 'warn', summary: 'Detalle requerido', detail: 'Agrega al menos un producto a la venta' });
      }
      return;
    }
    this.submitting = true;
    const value = this.form.getRawValue();
    const detalles = value.detalles as Array<{
      product_id: number;
      cantidad: number;
      precio_unitario: number;
      subtotal: number;
    }>;
    const venta: Venta = {
      usuario_id: value.usuario_id!,
      fecha: value.fecha,
      estado: value.estado,
      total: this.total,
      detalles: detalles.map(detalle => ({
        product_id: detalle.product_id!,
        cantidad: detalle.cantidad,
        precio_unitario: detalle.precio_unitario,
        subtotal: detalle.subtotal
      }))
    };
    const request = this.isEdit ? this.ventaService.update(this.ventaId!, venta) : this.ventaService.create(venta);
    request.subscribe({
      next: () => {
        this.messageService.add({ severity: 'success', summary: 'Éxito', detail: this.isEdit ? 'Venta actualizada' : 'Venta registrada' });
        setTimeout(() => this.router.navigate(['/ventas']), 1500);
      },
      error: err => {
        this.messageService.add({ severity: 'error', summary: 'Error', detail: err.error?.error ?? 'Error al guardar la venta' });
        this.submitting = false;
      }
    });
  }

  goBack(): void {
    this.router.navigate(['/ventas']);
  }

  private showCatalogError(catalog: string): void {
    this.messageService.add({ severity: 'error', summary: 'Error', detail: `No se pudieron cargar los ${catalog}` });
  }

  private getCurrentDateTime(): string {
    return this.toDateTimeLocal(new Date().toISOString());
  }

  private toDateTimeLocal(value: string): string {
    const date = new Date(value);
    const offset = date.getTimezoneOffset() * 60000;
    return new Date(date.getTime() - offset).toISOString().slice(0, 16);
  }
}

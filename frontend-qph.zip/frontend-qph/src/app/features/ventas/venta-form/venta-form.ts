import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormArray, FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../../../core/services/product';
import { VentaService } from '../../../core/services/venta';
import { Product } from '../../../shared/models/product.model';
import { Venta, VentaDetalle, VentaRequest } from '../../../shared/models/venta.model';
import { ButtonModule } from 'primeng/button';
import { InputNumberModule } from 'primeng/inputnumber';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-venta-form', standalone: true,
  imports: [CommonModule, ReactiveFormsModule, ButtonModule, InputNumberModule, ToastModule],
  providers: [MessageService], templateUrl: './venta-form.html', styleUrls: ['./venta-form.scss']
})
export class VentaFormComponent implements OnInit {
  private fb = inject(FormBuilder);
  private ventaService = inject(VentaService);
  private productService = inject(ProductService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private messageService = inject(MessageService);

  form = this.fb.nonNullable.group({ detalles: this.fb.array([]) });
  products: Product[] = [];
  isEdit = false;
  isAnulada = false;
  ventaId?: number;
  loading = false;
  submitting = false;

  get detalles(): FormArray { return this.form.controls.detalles; }

  get total(): number {
    return this.detalles.controls.reduce(
      (total, control) => total + this.getProductPrice(control.get('productId')?.value) * Number(control.get('cantidad')?.value ?? 0), 0
    );
  }

  ngOnInit(): void {
    this.loadProducts();
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEdit = true;
      this.ventaId = Number(id);
      this.loadVenta(this.ventaId);
    } else {
      this.addDetalle();
    }
  }

  private loadProducts(): void {
    this.productService.getAll().subscribe({
      next: products => this.products = products,
      error: () => this.showCatalogError()
    });
  }

  private loadVenta(id: number): void {
    this.loading = true;
    this.ventaService.getById(id).subscribe({
      next: venta => {
        venta.detalles.forEach(detalle => this.addDetalle(detalle));
        this.isAnulada = venta.estado === 'ANULADA';
        if (this.isAnulada) {
          this.form.disable();
          this.messageService.add({ severity: 'warn', summary: 'Venta anulada', detail: 'Las ventas anuladas no se pueden editar.' });
        }
        this.loading = false;
      },
      error: () => {
        this.messageService.add({ severity: 'error', summary: 'Error', detail: 'No se pudo cargar la venta' });
        this.loading = false;
      }
    });
  }

  addDetalle(detalle?: VentaDetalle): void {
    if (this.isAnulada) return;
    this.detalles.push(this.fb.group({
      productId: this.fb.control<number | null>(detalle?.productId ?? null, Validators.required),
      cantidad: this.fb.control(detalle?.cantidad ?? 1, [Validators.required, Validators.min(1)])
    }));
  }

  removeDetalle(index: number): void {
    if (!this.isAnulada) this.detalles.removeAt(index);
  }

  getProductPrice(productId: number | null | undefined): number {
    return this.products.find(product => product.id === productId)?.precio ?? 0;
  }

  onSubmit(): void {
    if (this.isAnulada || this.form.invalid || this.detalles.length === 0) {
      this.form.markAllAsTouched();
      if (!this.isAnulada && this.detalles.length === 0) {
        this.messageService.add({ severity: 'warn', summary: 'Detalle requerido', detail: 'Agrega al menos un producto a la venta' });
      }
      return;
    }
    this.submitting = true;
    const detalles = this.form.getRawValue().detalles as Array<{ productId: number; cantidad: number }>;
    const venta: VentaRequest = {
      detalles: detalles.map(detalle => ({ productId: detalle.productId, cantidad: detalle.cantidad }))
    };
    const request = this.isEdit ? this.ventaService.update(this.ventaId!, venta) : this.ventaService.create(venta);
    request.subscribe({
      next: () => {
        this.messageService.add({ severity: 'success', summary: 'Éxito', detail: this.isEdit ? 'Venta actualizada' : 'Venta registrada' });
        setTimeout(() => this.router.navigate(['/ventas']), 1500);
      },
      error: err => {
        this.messageService.add({ severity: 'error', summary: 'Error', detail: err.error?.error ?? 'Error al guardar la venta' });
        this.submitting = false;
      }
    });
  }

  goBack(): void { this.router.navigate(['/ventas']); }

  private showCatalogError(): void {
    this.messageService.add({ severity: 'error', summary: 'Error', detail: 'No se pudieron cargar los productos' });
  }
}

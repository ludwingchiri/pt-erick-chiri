import { Routes } from '@angular/router';

export const VENTA_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () => import('./venta-list/venta-list').then(m => m.VentaListComponent)
  },
  {
    path: 'new',
    loadComponent: () => import('./venta-form/venta-form').then(m => m.VentaFormComponent)
  },
  {
    path: 'edit/:id',
    loadComponent: () => import('./venta-form/venta-form').then(m => m.VentaFormComponent)
  }
];

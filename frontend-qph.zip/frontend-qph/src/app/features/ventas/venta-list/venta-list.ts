import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { VentaService } from '../../../core/services/venta';
import { Venta } from '../../../shared/models/venta.model';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { TagModule } from 'primeng/tag';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ToastModule } from 'primeng/toast';
import { ConfirmationService, MessageService } from 'primeng/api';

@Component({
  selector: 'app-venta-list',
  standalone: true,
  imports: [CommonModule, TableModule, ButtonModule, TagModule, ConfirmDialogModule, ToastModule],
  providers: [ConfirmationService, MessageService],
  templateUrl: './venta-list.html',
  styleUrls: ['./venta-list.scss']
})
export class VentaListComponent implements OnInit {
  private ventaService = inject(VentaService);
  private router = inject(Router);
  private confirmationService = inject(ConfirmationService);
  private messageService = inject(MessageService);

  ventas: Venta[] = [];
  loading = false;

  ngOnInit(): void {
    this.loadVentas();
  }

  loadVentas(): void {
    this.loading = true;
    this.ventaService.getAll().subscribe({
      next: data => {
        this.ventas = data;
        this.loading = false;
      },
      error: () => {
        this.messageService.add({ severity: 'error', summary: 'Error', detail: 'No se pudieron cargar las ventas' });
        this.loading = false;
      }
    });
  }

  goToCreate(): void {
    this.router.navigate(['/ventas/new']);
  }

  goToEdit(id: number): void {
    this.router.navigate(['/ventas/edit', id]);
  }

  confirmDelete(venta: Venta): void {
    if (venta.estado === 'ANULADA') return;
    this.confirmationService.confirm({
      message: `¿Estás seguro de anular la venta #${venta.id}?`,
      header: 'Confirmar anulación',
      icon: 'pi pi-exclamation-triangle',
      acceptLabel: 'Sí, anular',
      rejectLabel: 'Cancelar',
      acceptButtonStyleClass: 'p-button-danger',
      accept: () => this.deleteVenta(venta.id!)
    });
  }

  private deleteVenta(id: number): void {
    this.ventaService.delete(id).subscribe({
      next: () => {
        this.messageService.add({ severity: 'success', summary: 'Éxito', detail: 'Venta anulada correctamente' });
        this.loadVentas();
      },
      error: () => this.messageService.add({ severity: 'error', summary: 'Error', detail: 'No se pudo anular la venta' })
    });
  }

  getEstadoSeverity(estado: string): 'success' | 'danger' {
    return estado === 'REGISTRADA' ? 'success' : 'danger';
  }

  getUsuarioLabel(venta: Venta): string {
    if (!venta.usuario) return `Usuario #${venta.usuarioId}`;
    if (typeof venta.usuario === 'string') return venta.usuario;

    const nombreCompleto = [venta.usuario.nombre, venta.usuario.apellido].filter(Boolean).join(' ');
    return nombreCompleto || venta.usuario.usuario || `Usuario #${venta.usuarioId}`;
  }
}

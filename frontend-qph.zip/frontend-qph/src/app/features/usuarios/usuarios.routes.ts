import { Routes } from '@angular/router';

export const USUARIO_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./usuario-list/usuario-list').then(m => m.UsuarioListComponent)
  },
  {
    path: 'new',
    loadComponent: () =>
      import('./usuario-form/usuario-form').then(m => m.UsuarioFormComponent)
  },
  {
    path: 'edit/:id',
    loadComponent: () =>
      import('./usuario-form/usuario-form').then(m => m.UsuarioFormComponent)
  }
];

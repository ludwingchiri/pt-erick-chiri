import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UsuarioService } from '../../../core/services/usuario';
import { Usuario } from '../../../shared/models/usuario.model';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-usuario-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, ButtonModule, InputTextModule, ToastModule],
  providers: [MessageService],
  templateUrl: './usuario-form.html',
  styleUrls: ['./usuario-form.scss']
})
export class UsuarioFormComponent implements OnInit {
  private fb = inject(FormBuilder);
  private usuarioService = inject(UsuarioService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private messageService = inject(MessageService);

  form = this.fb.nonNullable.group({
    usuario: ['', [Validators.required, Validators.maxLength(100)]],
    nombre: ['', [Validators.required, Validators.maxLength(100)]],
    apellido: ['', [Validators.required, Validators.maxLength(100)]],
    contrasena: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(255)]],
    estado: true
  });
  isEdit = false;
  usuarioId?: number;
  loading = false;
  submitting = false;

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEdit = true;
      this.usuarioId = Number(id);
      this.loadUsuario(this.usuarioId);
    }
  }

  private loadUsuario(id: number): void {
    this.loading = true;
    this.usuarioService.getById(id).subscribe({
      next: usuario => {
        this.form.patchValue(usuario);
        this.loading = false;
      },
      error: () => {
        this.messageService.add({ severity: 'error', summary: 'Error', detail: 'No se pudo cargar el usuario' });
        this.loading = false;
      }
    });
  }

  onSubmit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.submitting = true;
    const data: Usuario = this.form.getRawValue();
    const request = this.isEdit ? this.usuarioService.update(this.usuarioId!, data) : this.usuarioService.create(data);
    request.subscribe({
      next: () => {
        this.messageService.add({ severity: 'success', summary: 'Éxito', detail: this.isEdit ? 'Usuario actualizado' : 'Usuario creado' });
        setTimeout(() => this.router.navigate(['/usuarios']), 1500);
      },
      error: err => {
        this.messageService.add({ severity: 'error', summary: 'Error', detail: err.error?.error ?? 'Error al guardar el usuario' });
        this.submitting = false;
      }
    });
  }

  goBack(): void {
    this.router.navigate(['/usuarios']);
  }
}

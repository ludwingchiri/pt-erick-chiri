/******************************
-  Nombre:      1.- Creación de base de datos
-  Descripción: Definición y creación del contenedor principal
               para el sistema de gestión de productos.
-  Tipo:        Estructura (Database)
-  Versión:     1.0
-  Autor:       Stalin Ladino
-  Fecha:       13-04-2026
*******************************/
CREATE DATABASE products_db;


/******************************
-  Nombre:      2.- Creación de tabla de productos
-  Descripción: Definición y creación de la tabla principal
               que almacena el catálogo de productos con
               control de precios y stock disponible.
-  Tipo:        Estructura (Table)
-  Versión:     1.0
-  Autor:       Stalin Ladino
-  Fecha:       13-04-2026
*******************************/
CREATE TABLE public.products (
    id      serial         NOT NULL,
    nombre  varchar(255)   NOT NULL,
    precio  numeric(38, 2) NOT NULL,
    stock   int4           NOT NULL,
    CONSTRAINT products_pkey       PRIMARY KEY (id),
    CONSTRAINT products_stock_check CHECK ((stock >= 0))
);

CREATE TABLE public.usuarios (
    id      serial         NOT NULL,
    usuario varchar(100)   NOT NULL,
    nombre  varchar(100)   NOT NULL,
    apellido varchar(100)  NOT NULL,
    contrasena  varchar(100) NOT NULL,
    estado   boolean       NOT NULL DEFAULT true,

    CONSTRAINT usuarios_pkey       PRIMARY KEY (id),
    CONSTRAINT usuarios_usuario_key UNIQUE (usuario)
);

CREATE TABLE public.ventas (
    id         serial         NOT NULL,
    usuario_id int4           NOT NULL,
    fecha      timestamp      NOT NULL,
    total      numeric(12, 2) NOT NULL,
    estado     varchar(20)    NOT NULL,

    CONSTRAINT ventas_pkey PRIMARY KEY (id),
    CONSTRAINT ventas_total_check CHECK ((total >= 0)),
    CONSTRAINT ventas_estado_check CHECK (estado IN ('REGISTRADA', 'ANULADA')),
    CONSTRAINT ventas_usuario_fk FOREIGN KEY (usuario_id)
        REFERENCES public.usuarios (id)
);

CREATE TABLE public.venta_detalles (
    id              serial         NOT NULL,
    venta_id        int4           NOT NULL,
    product_id      int4           NOT NULL,
    cantidad        int4           NOT NULL,
    precio_unitario numeric(12, 2) NOT NULL,
    subtotal        numeric(12, 2) NOT NULL,

    CONSTRAINT venta_detalles_pkey PRIMARY KEY (id),
    CONSTRAINT venta_detalles_cantidad_check CHECK ((cantidad > 0)),
    CONSTRAINT venta_detalles_precio_check CHECK ((precio_unitario >= 0)),
    CONSTRAINT venta_detalles_subtotal_check CHECK ((subtotal >= 0)),
    CONSTRAINT venta_detalles_venta_fk FOREIGN KEY (venta_id)
        REFERENCES public.ventas (id),
    CONSTRAINT venta_detalles_product_fk FOREIGN KEY (product_id)
        REFERENCES public.products (id)
);

INSERT INTO public.usuarios (usuario, nombre, apellido, contrasena, estado)
VALUES (
           'admin',
           'Admin',
           'Sistema',
           '$2a$10$eMSPwJfxqXRuTXFmPRKy2.CvXAMpOQ1q3Wgvc4cOkli9RuOBK5Cge', --admin123
           true
       );
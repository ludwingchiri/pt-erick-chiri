package com.example.demo.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VentaDTO {
    private Long id;

    private Long usuarioId;

    private String usuario;

    private LocalDateTime fecha;

    private BigDecimal total;

    private String estado;

    @Valid
    @NotEmpty(message = "La venta debe tener al menos un detalle")
    private List<VentaDetalleDTO> detalles;
}

package com.example.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VentaDTO {
    private Long id;

    private Long usuarioId;

    private String usuario;

    private LocalDateTime fecha;

    private BigDecimal total;

    private String estado;

    private List<VentaDetalleDTO> detalles;
}

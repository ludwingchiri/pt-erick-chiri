package com.example.demo.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UsuarioUpdateDTO {
    @NotBlank(message = "El usuario es requerido")
    @Size(max = 100, message = "El usuario no debe superar los 100 caracteres")
    private String usuario;

    @NotBlank(message = "El nombre es requerido")
    @Size(max = 100, message = "El nombre no debe superar los 100 caracteres")
    private String nombre;

    @NotBlank(message = "El apellido es requerido")
    @Size(max = 100, message = "El apellido no debe superar los 100 caracteres")
    private String apellido;

    private Boolean estado;
}

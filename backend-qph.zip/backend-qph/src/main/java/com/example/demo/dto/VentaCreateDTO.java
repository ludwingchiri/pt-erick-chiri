package com.example.demo.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VentaCreateDTO {
    @Valid
    @NotEmpty(message = "La venta debe tener al menos un detalle")
    private List<VentaDetalleRequestDTO> detalles;
}

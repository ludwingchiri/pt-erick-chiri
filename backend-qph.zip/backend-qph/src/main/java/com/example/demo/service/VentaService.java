package com.example.demo.service;

import com.example.demo.dto.VentaDTO;

import java.util.List;

public interface VentaService {

    List<VentaDTO> findAll();

    VentaDTO findById(Long id);

    VentaDTO create(VentaDTO dto);

    VentaDTO update(Long id, VentaDTO dto);

    void delete(Long id);
}

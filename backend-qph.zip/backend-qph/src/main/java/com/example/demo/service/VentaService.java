package com.example.demo.service;

import com.example.demo.dto.VentaCreateDTO;
import com.example.demo.dto.VentaDTO;
import com.example.demo.dto.VentaUpdateDTO;

import java.util.List;

public interface VentaService {

    List<VentaDTO> findAll();

    VentaDTO findById(Long id);

    VentaDTO create(VentaCreateDTO dto);

    VentaDTO update(Long id, VentaUpdateDTO dto);

    void delete(Long id);
}

package com.example.demo.service;

import com.example.demo.dto.UsuarioCreateDTO;
import com.example.demo.dto.UsuarioDTO;
import com.example.demo.dto.UsuarioUpdateDTO;

import java.util.List;

public interface UsuarioService {

    List<UsuarioDTO> findAll();

    UsuarioDTO findById(Long id);

    UsuarioDTO create(UsuarioCreateDTO dto);

    UsuarioDTO update(Long id, UsuarioUpdateDTO dto);

    void delete(Long id);
}

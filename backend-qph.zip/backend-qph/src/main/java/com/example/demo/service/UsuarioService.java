package com.example.demo.service;

import com.example.demo.dto.UsuarioDTO;

import java.util.List;

public interface UsuarioService {

    List<UsuarioDTO> findAll();

    UsuarioDTO findById(Long id);

    UsuarioDTO create(UsuarioDTO dto);

    UsuarioDTO update(Long id, UsuarioDTO dto);

    void delete(Long id);
}

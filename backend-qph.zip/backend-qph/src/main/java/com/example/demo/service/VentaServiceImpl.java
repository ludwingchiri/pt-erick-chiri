package com.example.demo.service;

import com.example.demo.dto.VentaCreateDTO;
import com.example.demo.dto.VentaDTO;
import com.example.demo.dto.VentaDetalleDTO;
import com.example.demo.dto.VentaDetalleRequestDTO;
import com.example.demo.dto.VentaUpdateDTO;
import com.example.demo.entity.Product;
import com.example.demo.entity.Usuario;
import com.example.demo.entity.Venta;
import com.example.demo.entity.VentaDetalle;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.ProductRepository;
import com.example.demo.repository.UsuarioRepository;
import com.example.demo.repository.VentaDetalleRepository;
import com.example.demo.repository.VentaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class VentaServiceImpl implements VentaService {

    private static final String ESTADO_REGISTRADA = "REGISTRADA";
    private static final String ESTADO_ANULADA = "ANULADA";

    private final VentaRepository ventaRepository;
    private final VentaDetalleRepository detalleRepository;
    private final UsuarioRepository usuarioRepository;
    private final ProductRepository productRepository;

    @Override
    @Transactional(readOnly = true)
    public List<VentaDTO> findAll() {
        return ventaRepository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public VentaDTO findById(Long id) {
        Venta venta = ventaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Venta no encontrada con id: " + id));
        return toDTO(venta);
    }

    @Override
    public VentaDTO create(VentaCreateDTO dto) {
        Usuario usuario = resolveAuthenticatedUsuario();

        Venta venta = Venta.builder()
                .usuario(usuario)
                .fecha(LocalDateTime.now())
                .estado(ESTADO_REGISTRADA)
                .total(BigDecimal.ZERO)
                .build();

        venta = ventaRepository.save(venta);
        List<VentaDetalle> detalles = buildDetalles(venta, dto.getDetalles());
        BigDecimal total = calcularTotal(detalles);
        venta.setTotal(total);
        venta = ventaRepository.save(venta);
        detalleRepository.saveAll(detalles);

        return toDTO(venta);
    }

    @Override
    public VentaDTO update(Long id, VentaUpdateDTO dto) {
        Venta existing = ventaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Venta no encontrada con id: " + id));
        validarVentaRegistrada(existing);

        List<VentaDetalle> currentDetails = detalleRepository.findByVentaId(id);
        restaurarStock(currentDetails);
        detalleRepository.deleteAll(currentDetails);
        detalleRepository.flush();

        List<VentaDetalle> newDetails = buildDetalles(existing, dto.getDetalles());
        existing.setTotal(calcularTotal(newDetails));
        Venta saved = ventaRepository.save(existing);
        detalleRepository.saveAll(newDetails);

        return toDTO(saved);
    }

    @Override
    public void delete(Long id) {
        Venta venta = ventaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Venta no encontrada con id: " + id));
        validarVentaRegistrada(venta);

        List<VentaDetalle> detalles = detalleRepository.findByVentaId(id);
        restaurarStock(detalles);
        venta.setEstado(ESTADO_ANULADA);
        ventaRepository.save(venta);
    }

    private List<VentaDetalle> buildDetalles(Venta venta, List<VentaDetalleRequestDTO> detalleDTOs) {
        List<VentaDetalle> detalles = new ArrayList<>();
        for (VentaDetalleRequestDTO detalleDTO : detalleDTOs) {
            Product product = findProductForUpdate(detalleDTO.getProductId());

            validarStock(product, detalleDTO.getCantidad());
            product.setStock(product.getStock() - detalleDTO.getCantidad());
            productRepository.save(product);

            BigDecimal precioUnitario = product.getPrecio();
            BigDecimal subtotal = precioUnitario.multiply(BigDecimal.valueOf(detalleDTO.getCantidad()));

            detalles.add(VentaDetalle.builder()
                    .venta(venta)
                    .product(product)
                    .cantidad(detalleDTO.getCantidad())
                    .precioUnitario(precioUnitario)
                    .subtotal(subtotal)
                    .build());
        }
        return detalles;
    }

    private void validarStock(Product product, Integer cantidad) {
        if (product.getStock() < cantidad) {
            throw new IllegalArgumentException(
                    "Stock insuficiente para el producto con id: " + product.getId());
        }
    }

    private void restaurarStock(List<VentaDetalle> detalles) {
        for (VentaDetalle detalle : detalles) {
            Product product = findProductForUpdate(detalle.getProduct().getId());
            product.setStock(product.getStock() + detalle.getCantidad());
            productRepository.save(product);
        }
    }

    private BigDecimal calcularTotal(List<VentaDetalle> detalles) {
        return detalles.stream()
                .map(VentaDetalle::getSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private Usuario resolveAuthenticatedUsuario() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null
                || !authentication.isAuthenticated()
                || authentication.getName() == null
                || "anonymousUser".equals(authentication.getName())) {
            throw new IllegalArgumentException("No se pudo identificar el usuario autenticado");
        }

        return usuarioRepository.findByUsuario(authentication.getName())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Usuario no encontrado: " + authentication.getName()));
    }

    private Product findProductForUpdate(Long productId) {
        return productRepository.findByIdForUpdate(productId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Producto no encontrado con id: " + productId));
    }

    private void validarVentaRegistrada(Venta venta) {
        if (!ESTADO_REGISTRADA.equals(venta.getEstado())) {
            throw new IllegalArgumentException(
                    "Solo se pueden modificar ventas en estado " + ESTADO_REGISTRADA);
        }
    }

    private VentaDTO toDTO(Venta venta) {
        List<VentaDetalleDTO> detalles = detalleRepository.findByVentaId(venta.getId())
                .stream()
                .map(this::toDetalleDTO)
                .collect(Collectors.toList());

        return VentaDTO.builder()
                .id(venta.getId())
                .usuarioId(venta.getUsuario().getId())
                .usuario(venta.getUsuario().getUsuario())
                .fecha(venta.getFecha())
                .total(venta.getTotal())
                .estado(venta.getEstado())
                .detalles(detalles)
                .build();
    }

    private VentaDetalleDTO toDetalleDTO(VentaDetalle detalle) {
        return VentaDetalleDTO.builder()
                .id(detalle.getId())
                .productId(detalle.getProduct().getId())
                .productNombre(detalle.getProduct().getNombre())
                .cantidad(detalle.getCantidad())
                .precioUnitario(detalle.getPrecioUnitario())
                .subtotal(detalle.getSubtotal())
                .build();
    }
}

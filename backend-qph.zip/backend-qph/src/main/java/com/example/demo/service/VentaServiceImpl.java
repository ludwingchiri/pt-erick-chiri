package com.example.demo.service;

import com.example.demo.dto.VentaDTO;
import com.example.demo.dto.VentaDetalleDTO;
import com.example.demo.entity.Product;
import com.example.demo.entity.Usuario;
import com.example.demo.entity.Venta;
import com.example.demo.entity.VentaDetalle;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.ProductRepository;
import com.example.demo.repository.UsuarioRepository;
import com.example.demo.repository.VentaDetalleRepository;
import com.example.demo.repository.VentaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class VentaServiceImpl implements VentaService {

    private static final String ESTADO_REGISTRADA = "REGISTRADA";

    private final VentaRepository ventaRepository;
    private final VentaDetalleRepository detalleRepository;
    private final UsuarioRepository usuarioRepository;
    private final ProductRepository productRepository;

    @Override
    @Transactional(readOnly = true)
    public List<VentaDTO> findAll() {
        return ventaRepository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public VentaDTO findById(Long id) {
        Venta venta = ventaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Venta no encontrada con id: " + id));
        return toDTO(venta);
    }

    @Override
    public VentaDTO create(VentaDTO dto) {
        Usuario usuario = resolveUsuario(dto);

        Venta venta = Venta.builder()
                .usuario(usuario)
                .fecha(dto.getFecha() != null ? dto.getFecha() : LocalDateTime.now())
                .estado(dto.getEstado() != null ? dto.getEstado() : ESTADO_REGISTRADA)
                .total(BigDecimal.ZERO)
                .build();

        venta = ventaRepository.save(venta);
        List<VentaDetalle> detalles = buildDetalles(venta, dto.getDetalles());
        BigDecimal total = calcularTotal(detalles);
        venta.setTotal(total);
        venta = ventaRepository.save(venta);
        detalleRepository.saveAll(detalles);

        return toDTO(venta);
    }

    @Override
    public VentaDTO update(Long id, VentaDTO dto) {
        Venta existing = ventaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Venta no encontrada con id: " + id));
        Usuario usuario = resolveUsuario(dto);

        List<VentaDetalle> currentDetails = detalleRepository.findByVentaId(id);
        restaurarStock(currentDetails);
        detalleRepository.deleteAll(currentDetails);
        detalleRepository.flush();

        existing.setUsuario(usuario);
        existing.setFecha(dto.getFecha() != null ? dto.getFecha() : existing.getFecha());
        existing.setEstado(dto.getEstado() != null ? dto.getEstado() : existing.getEstado());

        List<VentaDetalle> newDetails = buildDetalles(existing, dto.getDetalles());
        existing.setTotal(calcularTotal(newDetails));
        Venta saved = ventaRepository.save(existing);
        detalleRepository.saveAll(newDetails);

        return toDTO(saved);
    }

    @Override
    public void delete(Long id) {
        Venta venta = ventaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Venta no encontrada con id: " + id));
        List<VentaDetalle> detalles = detalleRepository.findByVentaId(id);
        restaurarStock(detalles);
        detalleRepository.deleteAll(detalles);
        ventaRepository.delete(venta);
    }

    private List<VentaDetalle> buildDetalles(Venta venta, List<VentaDetalleDTO> detalleDTOs) {
        List<VentaDetalle> detalles = new ArrayList<>();
        for (VentaDetalleDTO detalleDTO : detalleDTOs) {
            Product product = productRepository.findById(detalleDTO.getProductId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Producto no encontrado con id: " + detalleDTO.getProductId()));

            validarStock(product, detalleDTO.getCantidad());
            product.setStock(product.getStock() - detalleDTO.getCantidad());
            productRepository.save(product);

            BigDecimal precioUnitario = product.getPrecio();
            BigDecimal subtotal = precioUnitario.multiply(BigDecimal.valueOf(detalleDTO.getCantidad()));

            detalles.add(VentaDetalle.builder()
                    .venta(venta)
                    .product(product)
                    .cantidad(detalleDTO.getCantidad())
                    .precioUnitario(precioUnitario)
                    .subtotal(subtotal)
                    .build());
        }
        return detalles;
    }

    private void validarStock(Product product, Integer cantidad) {
        if (product.getStock() < cantidad) {
            throw new IllegalArgumentException(
                    "Stock insuficiente para el producto con id: " + product.getId());
        }
    }

    private void restaurarStock(List<VentaDetalle> detalles) {
        for (VentaDetalle detalle : detalles) {
            Product product = detalle.getProduct();
            product.setStock(product.getStock() + detalle.getCantidad());
            productRepository.save(product);
        }
    }

    private BigDecimal calcularTotal(List<VentaDetalle> detalles) {
        return detalles.stream()
                .map(VentaDetalle::getSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private Usuario resolveUsuario(VentaDTO dto) {
        if (dto.getUsuarioId() != null) {
            return usuarioRepository.findById(dto.getUsuarioId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Usuario no encontrado con id: " + dto.getUsuarioId()));
        }

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || authentication.getName() == null) {
            throw new IllegalArgumentException("No se pudo identificar el usuario autenticado");
        }

        return usuarioRepository.findByUsuario(authentication.getName())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Usuario no encontrado: " + authentication.getName()));
    }

    private VentaDTO toDTO(Venta venta) {
        List<VentaDetalleDTO> detalles = detalleRepository.findByVentaId(venta.getId())
                .stream()
                .map(this::toDetalleDTO)
                .collect(Collectors.toList());

        return VentaDTO.builder()
                .id(venta.getId())
                .usuarioId(venta.getUsuario().getId())
                .usuario(venta.getUsuario().getUsuario())
                .fecha(venta.getFecha())
                .total(venta.getTotal())
                .estado(venta.getEstado())
                .detalles(detalles)
                .build();
    }

    private VentaDetalleDTO toDetalleDTO(VentaDetalle detalle) {
        return VentaDetalleDTO.builder()
                .id(detalle.getId())
                .productId(detalle.getProduct().getId())
                .productNombre(detalle.getProduct().getNombre())
                .cantidad(detalle.getCantidad())
                .precioUnitario(detalle.getPrecioUnitario())
                .subtotal(detalle.getSubtotal())
                .build();
    }
}

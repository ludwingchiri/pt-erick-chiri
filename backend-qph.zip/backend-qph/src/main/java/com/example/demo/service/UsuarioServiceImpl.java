package com.example.demo.service;

import com.example.demo.dto.UsuarioCreateDTO;
import com.example.demo.dto.UsuarioDTO;
import com.example.demo.dto.UsuarioUpdateDTO;
import com.example.demo.entity.Usuario;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class UsuarioServiceImpl implements UsuarioService {

    private final UsuarioRepository repository;
    private final PasswordEncoder passwordEncoder;

    @Override
    @Transactional(readOnly = true)
    public List<UsuarioDTO> findAll() {
        return repository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public UsuarioDTO findById(Long id) {
        Usuario usuario = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Usuario no encontrado con id: " + id));
        return toDTO(usuario);
    }

    @Override
    public UsuarioDTO create(UsuarioCreateDTO dto) {
        validarUsuarioUnico(dto.getUsuario());
        Usuario usuario = toEntity(dto);
        return toDTO(repository.save(usuario));
    }

    @Override
    public UsuarioDTO update(Long id, UsuarioUpdateDTO dto) {
        Usuario existing = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Usuario no encontrado con id: " + id));
        validarUsuarioUnico(dto.getUsuario(), id);
        existing.setUsuario(dto.getUsuario());
        existing.setNombre(dto.getNombre());
        existing.setApellido(dto.getApellido());
        existing.setEstado(dto.getEstado() != null ? dto.getEstado() : true);
        return toDTO(repository.save(existing));
    }

    @Override
    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Usuario no encontrado con id: " + id);
        }
        repository.deleteById(id);
    }

    private UsuarioDTO toDTO(Usuario usuario) {
        return UsuarioDTO.builder()
                .id(usuario.getId())
                .usuario(usuario.getUsuario())
                .nombre(usuario.getNombre())
                .apellido(usuario.getApellido())
                .estado(usuario.getEstado())
                .build();
    }

    private Usuario toEntity(UsuarioCreateDTO dto) {
        return Usuario.builder()
                .usuario(dto.getUsuario())
                .nombre(dto.getNombre())
                .apellido(dto.getApellido())
                .contrasena(passwordEncoder.encode(dto.getContrasena()))
                .estado(dto.getEstado() != null ? dto.getEstado() : true)
                .build();
    }

    private void validarUsuarioUnico(String usuario) {
        if (repository.existsByUsuario(usuario)) {
            throw new IllegalArgumentException("Ya existe un usuario con username: " + usuario);
        }
    }

    private void validarUsuarioUnico(String usuario, Long id) {
        if (repository.existsByUsuarioAndIdNot(usuario, id)) {
            throw new IllegalArgumentException("Ya existe un usuario con username: " + usuario);
        }
    }
}

package com.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "usuarios", schema = "public")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    @NotBlank(message = "El usuario es requerido")
    private String usuario;

    @Column(nullable = false, length = 100)
    @NotBlank(message = "El nombre es requerido")
    private String nombre;

    @Column(nullable = false, length = 100)
    @NotBlank(message = "El apellido es requerido")
    private String apellido;

    @Column(nullable = false, length = 100)
    @NotBlank(message = "La contrasena es requerida")
    private String contrasena;

    @Column(nullable = false)
    @NotNull(message = "El estado es requerido")
    @Builder.Default
    private Boolean estado = true;
}
